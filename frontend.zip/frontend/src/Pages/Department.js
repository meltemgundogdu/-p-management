import React, { useState, useEffect } from 'react'; 
import axios from '../util/axios';
import Department from '../model/Department.ts';
import {
    MDBContainer,
    MDBRow,
    MDBCol,
    MDBCard,
    MDBCardBody,
    MDBCardTitle,
    MDBCardText,
    MDBInput,
    MDBBtn,
    MDBTable,
    MDBTableHead,
    MDBTableBody
} from 'mdb-react-ui-kit';

const Departments = () => {
    const [departments, setDepartments] = useState([]);
    const [newDepartment, setNewDepartment] = useState('');

    // Fetch departments on component mount
    useEffect(() => {
        loadDepartments();
    }, []);

    const loadDepartments = async () => {
        try {
            const response = await axios.get('/departments');
            setDepartments(response.data);
        } catch (error) {
            console.error('Error loading departments:', error);
        }
    };

    // Add a new department
    const handleAddDepartment = async (e) => {
        e.preventDefault();
        try {
            await axios.post('/departments', { name: newDepartment });
            loadDepartments(); // Refresh the list
            setNewDepartment(''); // Clear input field
        } catch (error) {
            console.error('Error adding department:', error);
        }
    };

    // Delete a department
    const handleDelete = async (id) => {
        try {
            await axios.delete(`/departments/${id}`);
            loadDepartments(); // Refresh the list
        } catch (error) {
            console.error('Error deleting department:', error);
        }
    };

    return (
        <MDBContainer>
            <MDBRow className="justify-content-center">
                <MDBCol md="8">
                    <MDBCard className="my-5">
                        <MDBCardBody>
                            <MDBCardTitle>Manage Departments</MDBCardTitle>
                            
                            {/* Form to add new department */}
                            <MDBCardText>
                                <form onSubmit={handleAddDepartment}>
                                    <MDBInput 
                                        label="New Department" 
                                        value={newDepartment}
                                        onChange={(e) => setNewDepartment(e.target.value)}
                                    />
                                    <MDBBtn type="submit" color="success" className="mt-2">
                                        Add Department
                                    </MDBBtn>
                                </form>
                            </MDBCardText>
                            
                            {/* Table to view all departments */}
                            <MDBCardText>
                                {departments.length > 0 ? (
                                    <MDBTable>
                                        <MDBTableHead>
                                            <tr>
                                                <th>#</th>
                                                <th>Department</th>
                                                <th>Actions</th>
                                            </tr>
                                        </MDBTableHead>
                                        <MDBTableBody>
                                            {departments.map((department, index) => (
                                                <tr key={department.id}>
                                                    <td>{index + 1}</td>
                                                    <td>{department.name}</td>
                                                    <td>
                                                        <MDBBtn color="danger" onClick={() => handleDelete(department.id)}>
                                                            Delete
                                                        </MDBBtn>
                                                    </td>
                                                </tr>
                                            ))}
                                        </MDBTableBody>
                                    </MDBTable>
                                ) : (
                                    <p>No departments found.</p>
                                )}
                            </MDBCardText>
                        </MDBCardBody>
                    </MDBCard>
                </MDBCol>
            </MDBRow>
        </MDBContainer>
    );
};

export default Departments;
