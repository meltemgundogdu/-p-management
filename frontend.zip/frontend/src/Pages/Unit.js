import React, { useState, useEffect } from 'react'; 
import axios from '../util/axios';
import {
    MDBContainer,
    MDBRow,
    MDBCol,
    MDBCard,
    MDBCardBody,
    MDBCardTitle,
    MDBCardText,
    MDBInput,
    MDBBtn,
    MDBTable,
    MDBTableHead,
    MDBTableBody
} from 'mdb-react-ui-kit';

const Units = () => {
    const [units, setUnits] = useState([]);
    const [newUnit, setNewUnit] = useState('');
    const [departments, setDepartments] = useState([]);  // Departmanlar için state tanımlaması
    const [selectedDepartment, setSelectedDepartment] = useState('');  // Seçilen departman

    // Fetch units on component mount
    useEffect(() => {
        loadUnits();
        loadDepartments();  // Departmanları yüklemek için fonksiyonu çağır
    }, []);

    const loadUnits = async () => {
        try {
            const response = await axios.get('/units');
            setUnits(response.data);
        } catch (error) {
            console.error('Error loading units:', error);
        }
    };

    const loadDepartments = async () => {
        try {
            const response = await axios.get('/departments');  // Departman listesini API'den çekiyoruz
            setDepartments(response.data);
        } catch (error) {
            console.error('Error loading departments:', error);
        }
    };

    // Add a new unit
    const handleAddUnit = async (e) => {
        e.preventDefault();
        if (!selectedDepartment) {
            console.error('Departman seçilmedi!');
            return;
        }
        try {
            await axios.post('/units', { 
                unitName: newUnit,  // 'unitName' olarak gönderdiğinden emin ol
                department: { id: selectedDepartment }  // Seçilen departman id'sini gönder
            });
            loadUnits();  // Listeyi yenile
            setNewUnit('');  // Input alanını temizle
            setSelectedDepartment('');  // Seçimi temizle
        } catch (error) {
            console.error('Error adding unit:', error);
        }
    };
    
    
    
    // Delete a unit
    const handleDelete = async (id) => {
        try {
            await axios.delete(`/units/${id}`);
            loadUnits(); // Refresh the list
        } catch (error) {
            console.error('Error deleting unit:', error);
        }
    };

    return (
        <MDBContainer>
            <MDBRow className="justify-content-center">
                <MDBCol md="8">
                    <MDBCard className="my-5">
                        <MDBCardBody>
                            <MDBCardTitle>Manage Units</MDBCardTitle>
                            
                            {/* Form to add new unit */}
                            <MDBCardText>
                                <form onSubmit={handleAddUnit}>
                                    <MDBInput 
                                        label="New Unit" 
                                        value={newUnit}
                                        onChange={(e) => setNewUnit(e.target.value)}
                                    />
                                    
                                    {/* Departman seçimi için dropdown */}
                                    <br></br>
                                    <div className='select'>
                                    <select
                                        value={selectedDepartment}
                                        onChange={(e) => setSelectedDepartment(e.target.value)}
                                    >
                                        <option value="">Departman Seçin</option>
                                        {departments.map((dep) => (
                                            <option key={dep.id} value={dep.id}>
                                                {dep.name}
                                            </option>
                                        ))}
                                    </select>
                                    </div>

                                    <MDBBtn type="submit" color="success" className="mt-2">
                                        Add Unit
                                    </MDBBtn>
                                </form>
                            </MDBCardText>
                            
                            {/* Table to view all units */}
                            <MDBCardText>
                                {units.length > 0 ? (
                                    <MDBTable>
                                        <MDBTableHead>
                                            <tr>
                                                <th>#</th>
                                                <th>Unit</th>
                                                <th>Actions</th>
                                            </tr>
                                        </MDBTableHead>
                                        <MDBTableBody>
                                            {units.map((unit, index) => (
                                                <tr key={unit.id}>
                                                    <td>{index + 1}</td>
                                                    <td>{unit.unitName}</td>
                                                    <td>
                                                        <MDBBtn color="danger" onClick={() => handleDelete(unit.id)}>
                                                            Delete
                                                        </MDBBtn>
                                                    </td>
                                                </tr>
                                            ))}
                                        </MDBTableBody>
                                    </MDBTable>
                                ) : (
                                    <p>No units found.</p>
                                )}
                            </MDBCardText>
                        </MDBCardBody>
                    </MDBCard>
                </MDBCol>
            </MDBRow>
        </MDBContainer>
    );
};

export default Units;
