import React, { useEffect, useState } from "react"; 
import axios from "../util/axios";
import SubIpAddresses from '../model/SubIpAddresses.ts'
import Department from "../model/Department.ts";
import { useParams } from "react-router-dom";
import {
    MDBBtn,
    MDBContainer,
    MDBRow,
    MDBCol,
    MDBTable,
    MDBTableBody,
    MDBTableHead,
} from "mdb-react-ui-kit";

export default function ViewIp() {
    const { id } = useParams();  // Ana IP'nin ID'sini almak için
    const [mainIp, setMainIp] = useState(null);  // Ana IP'yi tutar
    const [childIps, setChildIps] = useState([]);  // Alt IP'leri tutar
    const [newIp, setNewIp] = useState("");  // Yeni alt IP'yi tutar
    const [username, setUsername] = useState("");  // Kullanıcı adını tutar
    const [departments, setDepartments] = useState([]);  // Departmanları tutar
    const [units, setUnits] = useState([]);  // Seçilen departmana bağlı birimleri tutar
    const [selectedDepartment, setSelectedDepartment] = useState({});  // Seçilen departman
    const [selectedUnit, setSelectedUnit] = useState("");  // Seçilen birim

    // Ana IP'yi yükleyen fonksiyon
    const loadMainIp = async () => {
        try {
            const result = await axios.get(`/info/ip/${id}`);
            setMainIp(result.data.ip);  // Burada ip adresini result.data'dan alıyoruz
            console.log("Main ip:" + result.data.ip);
        } catch (error) {
            console.error("Error loading main IP:", error);
        }
    };


    useEffect(() => {
        loadDepartments();  // Sayfa yüklendiğinde departmanları getir
        loadMainIp();
    }, []);

    useEffect(() => {
        if (mainIp) {
            loadChildIps(mainIp);  // mainIp doğru set edilirse alt IP'leri yükle
        }
    }, [mainIp]);

    useEffect(() => {
        if (selectedDepartment) {
            console.log("department : " + selectedDepartment)
            loadUnits(selectedDepartment);  // Departman değiştiğinde ilgili birimleri yükle
        }
    }, [selectedDepartment]);

    // Departmanları yükleyen fonksiyon
    const loadDepartments = async () => {
        try {
            const response = await axios.get("/departments");  // Departmanları alıyoruz
            setDepartments(response.data);
        } catch (error) {
            console.error("Error loading departments:", error);
        }
    };

    // Seçilen departmana bağlı birimleri yükleyen fonksiyon
    const loadUnits = async (departmentId) => {
        try {
            const response = await axios.get(`/info/ip/departments/units/${departmentId}`);  // Seçilen departmanın birimlerini alıyoruz
            setUnits(response.data);
        } catch (error) {
            console.error("Error loading units:", error);
        }
    };

    // Alt IP'leri yükleyen fonksiyon
    const loadChildIps = async (ipAddress) => {
        try {
            const response = await axios.get(`/info/ip/byAddress/${ipAddress}/subips`);
            console.log("Alt IP'ler:", response.data);  // Gelen veriyi konsola yazdırın
            setChildIps(response.data);
        } catch (error) {
            console.error("Alt IP'leri yüklerken hata oluştu:", error);
        }
    };
    
    // Yeni alt IP ekleyen fonksiyon
    const addChildIp = async () => {
        try {
            const response = await axios.post("/info/subips", {
                subip: newIp,  // Eklenen alt IP
                ipAddress: { id: id },  // Ana IP ile ilişkilendiriyoruz
                parentIp: { id: id },  // parentIp de set ediliyor
                userName: username,
                department: {id:selectedDepartment},  // Seçilen departman
                unit: {id:selectedUnit}  // Seçilen birim
            });
            console.log("Alt IP başarıyla eklendi:", response.data);
            console.log("selected unit:"+selectedUnit);
            setNewIp("");  // Inputları temizle
            setUsername("");
            setSelectedDepartment({});
            setSelectedUnit({});
            loadChildIps(mainIp);  // Alt IP'leri tekrar yükle
        } catch (error) {
            console.error("Alt IP eklenirken hata oluştu:", error.response || error);
        }
    };
    
    const deleteChildIp = async (childIpId) => {
        if (!childIpId) {
            console.error("Silinecek alt IP'nin ID'si tanımlı değil.");
            return;
        }
        try {
            console.log("Silinecek alt IP'nin ID'si:", childIpId);
            await axios.delete(`/info/subips/${childIpId}`);
            loadChildIps(mainIp);  // Silme işleminden sonra alt IP'leri tekrar yükle
        } catch (error) {
            console.error("Alt IP silinirken hata oluştu:", error);
        }
    };
    
    //const selectUnits = async (unit)

    return (
        <MDBContainer fluid>
            <MDBRow className="my-4">
                <MDBCol md="12">
                    {mainIp && (
                        <div>
                            <h1>Ana IP: {mainIp}</h1>
                            <MDBTable striped bordered hover>
                                <MDBTableHead>
                                    <tr>
                                         <th>Alt IP Adresi</th>
                                         <th>Kullanıcı</th>
                                         <th>Departman</th> {/* Başkanlık sütunu */}
                                         <th>Birim</th> {/* Birim sütunu */}
                                         <th>İşlem</th>
                                    </tr>
                                </MDBTableHead>
                                <MDBTableBody>
                                  {childIps.map((childIp, index) => (
                                       <tr key={childIp.subid || index}>
                                           <td>{childIp.subip}</td>
                                           <td>{childIp.userName}</td>
                                           <td>{childIp.department.name}</td>
                                           <td>{childIp.unit.unitName}</td>
                                           <td>
                                               <MDBBtn color="danger" size="sm" onClick={() => deleteChildIp(childIp.subid)}>
                                                    Delete
                                               </MDBBtn>
                                           </td>
                                        </tr>
                                    ))}
                                 </MDBTableBody>
                            </MDBTable>
                            <div className="mt-4">
                                <input
                                    type="text"
                                    placeholder="Yeni Alt IP Adresi"
                                    value={newIp}
                                    onChange={(e) => setNewIp(e.target.value)}
                                />
                                <br /><br />
                                <input
                                    type="text"
                                    placeholder="Kullanıcı Adı"
                                    value={username}
                                    onChange={(e) => setUsername(e.target.value)}
                                />
                                <br /><br />
                                {/* Departman Dropdown */}
                                <div className="select"><select
                                    value={selectedDepartment}
                                    onChange={(e) => setSelectedDepartment(e.target.value)}
                                >
                                    <option value="">Departman Seçin</option>
                                    {departments.map((dept) => (
                                        <option key={dept.id} value={dept.id}>
                                            {dept.name}
                                        </option>
                                    ))}
                                </select>
                                <br /><br />
                                {/* Birim Dropdown */}
                                <select
                                    value={selectedUnit}
                                    onChange={(e) => setSelectedUnit(e.target.value)} 
                                    disabled={!selectedDepartment}  /* Departman seçilmezse birim seçilemez */
                                >
                                    <option value="">Birim Seçin</option>
                                    {units.map((unit) => (
                                        <option key={unit.id} value={unit.id}> 
                                            {unit.unitName}
                                        </option>
                                    ))}
                                </select>
                                </div>
                                <br /><br />
                                <MDBBtn onClick={addChildIp}>ADD</MDBBtn>
                            </div>
                        </div>
                    )}
                </MDBCol>
            </MDBRow>
        </MDBContainer>
    );
}
