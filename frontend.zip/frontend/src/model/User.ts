import { Role } from "./Role";

export default class User {
  id: Number;
  username: String;
  password: String;
  user: Role.USER | Role.ADMIN;
}