export default class OperatingSystem{
    id:Number;
    name:String;
}