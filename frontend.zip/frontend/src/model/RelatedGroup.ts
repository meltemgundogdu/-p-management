export default class RelatedGroup{
    id:Number;
    name:String;
}