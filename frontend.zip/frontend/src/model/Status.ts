export default class Status{
    id:Number;
    name:String;
}