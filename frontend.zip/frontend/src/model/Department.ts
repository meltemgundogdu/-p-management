export default class Department{
    id:Number;
    name:String;
}