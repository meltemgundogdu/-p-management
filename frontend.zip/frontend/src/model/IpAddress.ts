import User from './User'
export default class IpAddress{

     id:Number;

     ip:String;

     hostName:String;

     status:String;

    location:String;

    relatedGroup:String;

     operatingSystem:String; 

     user:User;  // IP adresini kullanan kişi
}
