import Department from "./Department";

export default class Status{
    id:Number;
    unitName:String;
    department:Department
}