export default class Location{
    id:Number;
    name:String;
}