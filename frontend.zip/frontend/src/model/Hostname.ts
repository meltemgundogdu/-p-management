export default class HostNames{
    id:Number;
    name:String;
}