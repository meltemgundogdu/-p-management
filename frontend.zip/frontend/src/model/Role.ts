export enum Role{
    USER = "USER",
    ADMIN = "ADMIN"
}