import IpAddress from "./IpAddress";
import User from "./User";
import Department from "./Department";
import Unit from "./Unit";

export default class SubIpAddress{
    subid:Number;
    subip:String;
    userName:String;
    ipAddress:IpAddress;
    user:User;
    parentIp:IpAddress;
    department:Department;
    unit:Unit;
}