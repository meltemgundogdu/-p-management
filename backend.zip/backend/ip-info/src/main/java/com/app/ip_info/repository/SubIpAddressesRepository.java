package com.app.ip_info.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.app.ip_info.entity.IpAddress;
import com.app.ip_info.entity.SubIpAddresses;

@Repository
public interface SubIpAddressesRepository extends JpaRepository<SubIpAddresses, Long> {

    // Ana IP'ye göre alt IP'leri getir
    List<SubIpAddresses> findByIpAddress(IpAddress ipAddress);
    
    // Ana IP'nin prefixine göre alt IP'leri getirirken joker karakter % doğru şekilde kullanıldı
    @Query("SELECT s FROM SubIpAddresses s WHERE s.subip LIKE CONCAT(:prefix, '%')")
    List<SubIpAddresses> findByIpPrefix(@Param("prefix") String mainIpPrefix);

    void deleteById(Long id);
}
