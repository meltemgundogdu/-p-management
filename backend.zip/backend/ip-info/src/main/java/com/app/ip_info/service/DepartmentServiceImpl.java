package com.app.ip_info.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.ip_info.entity.Department;
import com.app.ip_info.repository.DepartmentRepository;

@Service
public class DepartmentServiceImpl implements DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;

    @Override
    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }
    @Override
    public Department addDepartment(Department department) {
        return departmentRepository.save(department);
    }
    @Override
    public void deleteDepartment(Long id) {
        departmentRepository.deleteById(id);
    }
    @Override
    public Department findByID(Long id) {
        return departmentRepository.findById(id).get();
    }
}
