package com.app.ip_info.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.ip_info.entity.Unit;
import com.app.ip_info.service.UnitService;

@RestController
@RequestMapping("/units")
public class UnitController {

    @Autowired
    private UnitService unitService;

    @GetMapping
    public ResponseEntity<List<Unit>> getAllUnits() {
        List<Unit> units = unitService.findAll();
        return new ResponseEntity<>(units, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Unit> addUnit(@RequestBody Unit unit) {
    if (unit.getUnitName() == null || unit.getUnitName().isEmpty()) {
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Eksik veri kontrolü
    }
    Unit createdUnit = unitService.addUnit(unit);
    return new ResponseEntity<>(createdUnit, HttpStatus.CREATED);
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUnit(@PathVariable Long id) {
        unitService.deleteUnit(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
