package com.app.ip_info.service;

import java.util.List;
import java.util.Optional;

import com.app.ip_info.entity.IpAddress;
import com.app.ip_info.exception.IpAddressNotFoundException;

public interface IpService {

    List<IpAddress> getAllIpAddresses();

    Optional<IpAddress> findIpAddressById(Long id) throws IpAddressNotFoundException;

    List<IpAddress> findRelatedIPs(String relatedGroup);

    IpAddress saveIpAddress(IpAddress ipAddress, boolean update) throws Exception;

    void deleteIpAddressById(Long id) throws IpAddressNotFoundException;
}
