package com.app.ip_info.service;

import java.util.List;  // List import edildi

import com.app.ip_info.entity.Department;
import com.app.ip_info.entity.Unit;


public interface UnitService {

    public List<Unit> findByDepartment(Department department);
    public List<Unit> findAll();
    public void deleteUnit(Long id);
    public Unit addUnit(Unit unit);
    
  
}
