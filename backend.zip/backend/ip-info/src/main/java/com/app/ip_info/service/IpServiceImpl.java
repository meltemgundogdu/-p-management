package com.app.ip_info.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.ip_info.entity.IpAddress;
import com.app.ip_info.repository.IpRepository;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class IpServiceImpl implements IpService {

    @Autowired
    private IpRepository ipRepository;

    @Override
    public List<IpAddress> getAllIpAddresses() {
        return ipRepository.findAll();
    }

    @Override
    public Optional<IpAddress> findIpAddressById(Long id) throws IpAddressNotFoundException {
        Optional<IpAddress> ipAddress = ipRepository.findById(id);
        if (!ipAddress.isPresent()) {
            throw new IpAddressNotFoundException("IP Address not found with ID: " + id);
        }
        return ipAddress;
    }

    @Override
    public List<IpAddress> findRelatedIPs(String relatedGroup) {
        return ipRepository.findByRelatedGroup(relatedGroup);
    }

    @Override
    public IpAddress saveIpAddress(IpAddress ipAddress, boolean update) throws Exception {
        if (!update && ipRepository.existsByIp(ipAddress.getIp())) {
            throw new IpAddressAlreadyExistsException("IP Address already exists: " + ipAddress.getIp());
        }
        return ipRepository.save(ipAddress);
    }

    @Override
    public void deleteIpAddressById(Long id) throws IpAddressNotFoundException {
        if (!ipRepository.existsById(id)) {
            throw new IpAddressNotFoundException("IP Address not found with ID: " + id);
        }
        ipRepository.deleteById(id);
    }

    public class IpAddressNotFoundException extends RuntimeException {

        public IpAddressNotFoundException(String message, String details) {
            super(message + ": " + details);
        }
    
        // Tek parametreli yapıcı eklemeye devam edebiliriz
        public IpAddressNotFoundException(String message) {
            super(message);
        }
    }

    public class IpAddressAlreadyExistsException extends RuntimeException {

        public IpAddressAlreadyExistsException(String message, String details) {
            super(message + ": " + details);
        }
    
        // Tek parametreli yapıcı eklemeye devam edebiliriz
        public IpAddressAlreadyExistsException(String message) {
            super(message);
        }
    }
}
