package com.app.ip_info.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Sub_Ip_Addresses")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SubIpAddresses {
    
    @Id
    @Column(name = "SUB_ID", nullable = false)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long subid;

    @Column(name = "SUB_IP_ADDRESS", nullable = false)
    private String subip;

    @Column(name = "USER_NAME", nullable = true)
    private String userName;

    // Alt IP adresini bir ana IP ile ilişkilendiriyoruz
    @ManyToOne
    @JoinColumn(name = "ip_address_id", nullable = false)  // Ana IP adresi ile ilişki kuran sütun
    private IpAddress ipAddress;  // Ana IP adresi
    
    // Kullanıcı ile ilişkilendirme (isteğe bağlı)
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;  // IP adresini kullanan kişi
    
    @ManyToOne
    @JoinColumn(name = "parent_ip_id", nullable = false)  // Zorunlu bir ilişki
    private IpAddress parentIp;

    @ManyToOne
    @JoinColumn(name = "department_id")
    private Department department;  // Başkanlık

    @ManyToOne
    @JoinColumn(name = "unit_id")
    private Unit unit;  // Birim

    public IpAddress getParentIp() {
        return this.parentIp;
    }
    
    public void setParentIp(IpAddress parentIp) {
        this.parentIp = parentIp;
    }
    
}
