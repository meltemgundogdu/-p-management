package com.app.ip_info.controller;

import java.util.List;
import java.util.Optional;

import static org.springframework.beans.BeanUtils.copyProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.ip_info.entity.Department;
import com.app.ip_info.entity.IpAddress;
import com.app.ip_info.entity.SubIpAddresses;
import com.app.ip_info.entity.Unit;
import com.app.ip_info.exception.IpAddressAlreadyExistsException;
import com.app.ip_info.exception.IpAddressNotFoundException;
import com.app.ip_info.exception.ResourceNotFoundException;
import com.app.ip_info.model.IpRequest;
import com.app.ip_info.model.IpResponse;
import com.app.ip_info.repository.IpRepository;
import com.app.ip_info.repository.SubIpAddressesRepository;
import com.app.ip_info.service.DepartmentService;
import com.app.ip_info.service.IpService;
import com.app.ip_info.service.UnitService;

import lombok.extern.log4j.Log4j2;

@RestController
@RequestMapping("/info")
@Log4j2
@CrossOrigin(origins = "http://localhost:3000")
public class IpAddressController {
    
    @Autowired
    private IpService ipService;

    @Autowired
    private IpRepository ipRepository;

    @Autowired
    private SubIpAddressesRepository subIpAddressesRepository;

    @Autowired
    private UnitService unitService;

    @Autowired
    private DepartmentService departmentService;

    // Tüm IP adreslerini listeleme
    @GetMapping("/ip")
    public List<IpAddress> getAllIpAddresses() {
        return ipService.getAllIpAddresses();
    }

    // ID'ye göre IP adresi alma
    @GetMapping("/ip/{id}")
    public ResponseEntity<IpResponse> getIpAddressById(@PathVariable Long id) {
        Optional<IpAddress> ipAddress = ipService.findIpAddressById(id);
        if (!ipAddress.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        IpResponse ipResponse = new IpResponse();
        copyProperties(ipAddress.get(), ipResponse);
        return new ResponseEntity<>(ipResponse, HttpStatus.OK);
    }

    // Yeni IP adresi ekleme
    @PostMapping("/ip")
    public ResponseEntity<IpAddress> addIpAddress(@RequestBody IpAddress ipAddress) {
        try {
            IpAddress savedIpAddress = ipService.saveIpAddress(ipAddress, false);
            return new ResponseEntity<>(savedIpAddress, HttpStatus.CREATED);
        } catch (IpAddressAlreadyExistsException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(null);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    // IP adresi silme
    @DeleteMapping("/ip/{id}")
    public ResponseEntity<Void> deleteIpAddress(@PathVariable Long id) {
        try {
            ipService.deleteIpAddressById(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // IP adresi güncelleme
    @PutMapping("/ip/{id}")
    public ResponseEntity<IpResponse> updateIpAddress(@PathVariable Long id, @RequestBody IpRequest ipRequest) {
        try {
            Optional<IpAddress> existingIpAddress = ipService.findIpAddressById(id);
            if (!existingIpAddress.isPresent()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }

            IpResponse ipResponse = new IpResponse();
            copyProperties(existingIpAddress.get(), ipResponse);

            ipResponse.setIp(ipRequest.getIp());
            ipResponse.setHostName(ipRequest.getHostName());
            ipResponse.setStatus(ipRequest.getStatus());
            ipResponse.setLocation(ipRequest.getLocation());
            ipResponse.setRelatedGroup(ipRequest.getRelatedGroup());
            ipResponse.setOperatingSystem(ipRequest.getOperatingSystem());

            IpAddress updatedIpAddress = new IpAddress();
            copyProperties(ipResponse, updatedIpAddress);

            IpAddress savedIpAddress = ipService.saveIpAddress(updatedIpAddress, true);
            IpResponse updatedIpResponse = new IpResponse();
            copyProperties(savedIpAddress, updatedIpResponse);

            return ResponseEntity.ok(updatedIpResponse);
        } catch (IpAddressNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        } catch (IpAddressAlreadyExistsException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(null);
        } catch (Exception e) {
            log.error("Error updating IP address", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @CrossOrigin(origins = "http://localhost:3000")
    // Alt IP adreslerini getiren endpoint
    @GetMapping("/ip/byAddress/{ip}/subips")
    public ResponseEntity<List<SubIpAddresses>> getSubIpsByIpAddress(@PathVariable String ip) {
    try {
        // Ana IP'yi IP adresine göre bul
        IpAddress mainIpEntity = ipRepository.findByIp(ip);
        
        if (mainIpEntity == null) {
            throw new ResourceNotFoundException("Ana IP bulunamadı: " + ip);
        }
        
        // Ana IP'nin ilk 3 oktetini al
        String[] mainIpParts = ip.split("\\.");
        String mainIpPrefix = mainIpParts[0] + "." + mainIpParts[1] + "." + mainIpParts[2];
        
        // Yeni repository sorgusunu kullanarak alt IP'leri getir
        List<SubIpAddresses> filteredSubIps = subIpAddressesRepository.findByIpPrefix(mainIpPrefix);
        
        return ResponseEntity.ok(filteredSubIps);
    } catch (Exception e) {
        log.error("Alt IP'leri alırken hata oluştu", e);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
}


    // Alt IP ekleme
    @PostMapping("/subips")
    public ResponseEntity<SubIpAddresses> addSubIp(@RequestBody SubIpAddresses subIp) {
        if (subIp.getParentIp() == null || subIp.getParentIp().getId() == null) {
            throw new IllegalArgumentException("Parent IP Address is required for adding a sub IP.");
        }
        
        SubIpAddresses savedSubIp = subIpAddressesRepository.save(subIp);
        return new ResponseEntity<>(savedSubIp, HttpStatus.CREATED);
    }

    // Alt IP silme
    @DeleteMapping("/subips/{id}")
    public ResponseEntity<Void> deleteSubIp(@PathVariable Long id) {
        try {
            subIpAddressesRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            log.error("Alt IP silinirken hata oluştu", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @GetMapping("/ip/departments/units/{departmentId}")
    public ResponseEntity<List<Unit>> getUnitsByDepartmentId(@PathVariable Long departmentId) {
    try {
        // Deparment id ye gore unitleri secer
        Department department = departmentService.findByID(departmentId);
        List<Unit> listUnits = unitService.findByDepartment(department);
        
        if (listUnits == null || listUnits.size()<=0) {
            throw new ResourceNotFoundException("Deparmant id bulunamadı: " + departmentId);
        }        
        return ResponseEntity.ok(listUnits);
    } catch (Exception e) {
        log.error("Unitleri çekerken hata oluştu", e);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
}

}
