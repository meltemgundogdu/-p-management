package com.app.ip_info.service;

import java.util.List;  // List import edildi

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.ip_info.entity.Department;
import com.app.ip_info.entity.Unit;
import com.app.ip_info.repository.UnitRepository;

@Service
public class UnitServiceImpl implements UnitService{

    @Autowired
    private UnitRepository unitRepository;

  

    @Override
    public List<Unit> findByDepartment(Department department) {
        return unitRepository.findByDepartment(department);
    }

    @Override
    public List<Unit> findAll() {
        return unitRepository.findAll();
    }

    @Override
    public void deleteUnit(Long id) {
        // TODO Auto-generated method stub
       unitRepository.deleteById(id);
    }

    @Override
    public Unit addUnit(Unit unit) {
        unitRepository.save(unit);
        return unit;
    }
 
}
