package com.app.ip_info;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IpInfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(IpInfoApplication.class, args);
	}

}
