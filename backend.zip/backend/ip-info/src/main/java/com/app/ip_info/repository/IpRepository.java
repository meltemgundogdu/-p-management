package com.app.ip_info.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.ip_info.entity.IpAddress;

public interface IpRepository extends JpaRepository<IpAddress, Long> {
    
    boolean existsByIp(String ip);

    IpAddress findByIp(String ip);

    // Belirli bir gruba bağlı olan tüm IP adreslerini getiren metod
    List<IpAddress> findByRelatedGroup(String relatedGroup);
}
