package com.app.ip_info.model;

public enum Role {
    USER,
    ADMIN
}
