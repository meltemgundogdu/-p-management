package com.app.ip_info.service;

import java.util.List;

import com.app.ip_info.entity.Department;


public interface DepartmentService {

    public List<Department> getAllDepartments();

    public Department addDepartment(Department department);

    public void deleteDepartment(Long id);

    public Department findByID(Long id);
}

