package com.app.ip_info.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Ip_Addresses")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class IpAddress {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column (name = "ip_id", nullable = false)
    private Long id;

    @Column(name = "IP_ADDRESS", nullable = false)
    private String ip;

    @Column(name = "HOST_NAME", nullable = true)
    private String hostName;

    @Column(name = "STATUS", nullable = true)
    private String status;

    @Column(name = "LOCATION", nullable = true)
    private String location;

    @Column(name = "RELATED_GROUP", nullable = true)
    private String relatedGroup;

    @Column(name = "OPERATING_SYSTEM", nullable = true)
    private String operatingSystem;

    // Kullanan kullanıcı ile ilişkilendirme
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;  // IP adresini kullanan kişi
}
