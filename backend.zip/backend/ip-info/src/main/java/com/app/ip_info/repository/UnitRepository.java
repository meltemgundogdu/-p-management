package com.app.ip_info.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.ip_info.entity.Department;
import com.app.ip_info.entity.Unit;

public interface UnitRepository extends JpaRepository<Unit, Long> {
    List<Unit> findByDepartment(Department department);
}
