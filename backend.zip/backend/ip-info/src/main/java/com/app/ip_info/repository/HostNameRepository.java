package com.app.ip_info.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.ip_info.entity.HostName;


public interface HostNameRepository extends JpaRepository<HostName, Long> {
}
