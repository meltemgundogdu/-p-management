package com.app.ip_info;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IpInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
